"""
Şampiyonlar Tahmin Ligi — Flask + SQLite (lokal geliştirme sürümü)

Gerçek para / bahis / ödeme YOKTUR. Gruplar sadece metin halinde
sosyal kural tutabilir (örn. "haftanın sonuncusu kahve ısmarlar").
"""
import os
import secrets
from datetime import datetime, timezone

from flask import Flask, render_template, redirect, url_for, request, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user,
)
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "lokal-gelistirme-anahtari-degistir")
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'tahmin_ligi.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = "giris"
login_manager.login_message = "Devam etmek için giriş yapman gerekiyor."


def simdi():
    return datetime.now(timezone.utc)


# ============ MODELLER ============

class Kullanici(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kullanici_adi = db.Column(db.String(50), unique=True, nullable=False)
    sifre_hash = db.Column(db.String(255), nullable=False)
    olusturulma = db.Column(db.DateTime, default=simdi)


class Grup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ad = db.Column(db.String(100), nullable=False)
    davet_kodu = db.Column(db.String(10), unique=True, nullable=False,
                            default=lambda: secrets.token_hex(4))
    sezon = db.Column(db.String(20), default="2025-2026")
    # Sosyal kural SADECE metin — para/ödeme ile ilgisi yoktur
    sosyal_kural = db.Column(db.String(300), nullable=True)
    kurucu_id = db.Column(db.Integer, db.ForeignKey("kullanici.id"), nullable=False)
    olusturulma = db.Column(db.DateTime, default=simdi)


class GrupUyeligi(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    grup_id = db.Column(db.Integer, db.ForeignKey("grup.id"), nullable=False)
    kullanici_id = db.Column(db.Integer, db.ForeignKey("kullanici.id"), nullable=False)
    katilma_tarihi = db.Column(db.DateTime, default=simdi)
    __table_args__ = (db.UniqueConstraint("grup_id", "kullanici_id"),)


class Mac(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ev_sahibi = db.Column(db.String(100), nullable=False)
    deplasman = db.Column(db.String(100), nullable=False)
    lig = db.Column(db.String(100), default="Süper Lig")
    baslangic = db.Column(db.DateTime, nullable=False)
    durum = db.Column(db.String(20), default="planlandi")  # planlandi | bitti
    ev_skor = db.Column(db.Integer, nullable=True)
    deplasman_skor = db.Column(db.Integer, nullable=True)

    def basladi_mi(self):
        bl = self.baslangic
        if bl.tzinfo is None:
            bl = bl.replace(tzinfo=timezone.utc)
        return bl <= simdi()


class Tahmin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    grup_id = db.Column(db.Integer, db.ForeignKey("grup.id"), nullable=False)
    mac_id = db.Column(db.Integer, db.ForeignKey("mac.id"), nullable=False)
    kullanici_id = db.Column(db.Integer, db.ForeignKey("kullanici.id"), nullable=False)
    tahmin_ev = db.Column(db.Integer, nullable=False)
    tahmin_deplasman = db.Column(db.Integer, nullable=False)
    puan = db.Column(db.Integer, nullable=True)
    guncelleme = db.Column(db.DateTime, default=simdi, onupdate=simdi)
    __table_args__ = (db.UniqueConstraint("grup_id", "mac_id", "kullanici_id"),)


@login_manager.user_loader
def kullanici_yukle(kullanici_id):
    return db.session.get(Kullanici, int(kullanici_id))


# ============ PUANLAMA MANTIĞI ============
# Kesin skor doğru: 5 puan | sadece sonuç (1/X/2) doğru: 2 puan | yanlış: 0 puan

def mac_puanlarini_hesapla(mac: Mac):
    if mac.durum != "bitti" or mac.ev_skor is None:
        return
    tahminler = Tahmin.query.filter_by(mac_id=mac.id).all()
    for t in tahminler:
        if t.tahmin_ev == mac.ev_skor and t.tahmin_deplasman == mac.deplasman_skor:
            t.puan = 5
        elif _isaret(t.tahmin_ev - t.tahmin_deplasman) == _isaret(mac.ev_skor - mac.deplasman_skor):
            t.puan = 2
        else:
            t.puan = 0
    db.session.commit()


def _isaret(x):
    return (x > 0) - (x < 0)


# ============ AUTH ROUTE'LARI ============

@app.route("/kayit", methods=["GET", "POST"])
def kayit():
    if current_user.is_authenticated:
        return redirect(url_for("gruplar"))
    if request.method == "POST":
        kullanici_adi = request.form["kullanici_adi"].strip()
        sifre = request.form["sifre"]
        if len(kullanici_adi) < 3:
            flash("Kullanıcı adı en az 3 karakter olmalı.", "hata")
        elif len(sifre) < 4:
            flash("Şifre en az 4 karakter olmalı.", "hata")
        elif Kullanici.query.filter_by(kullanici_adi=kullanici_adi).first():
            flash("Bu kullanıcı adı zaten alınmış.", "hata")
        else:
            k = Kullanici(kullanici_adi=kullanici_adi, sifre_hash=generate_password_hash(sifre))
            db.session.add(k)
            db.session.commit()
            login_user(k)
            return redirect(url_for("gruplar"))
    return render_template("kayit.html")


@app.route("/giris", methods=["GET", "POST"])
def giris():
    if current_user.is_authenticated:
        return redirect(url_for("gruplar"))
    if request.method == "POST":
        kullanici_adi = request.form["kullanici_adi"].strip()
        sifre = request.form["sifre"]
        k = Kullanici.query.filter_by(kullanici_adi=kullanici_adi).first()
        if k and check_password_hash(k.sifre_hash, sifre):
            login_user(k)
            return redirect(url_for("gruplar"))
        flash("Kullanıcı adı veya şifre hatalı.", "hata")
    return render_template("giris.html")


@app.route("/cikis")
@login_required
def cikis():
    logout_user()
    return redirect(url_for("giris"))


# ============ GRUP ROUTE'LARI ============

@app.route("/")
def anasayfa():
    return redirect(url_for("gruplar") if current_user.is_authenticated else url_for("giris"))


@app.route("/gruplar", methods=["GET", "POST"])
@login_required
def gruplar():
    if request.method == "POST":
        eylem = request.form.get("eylem")
        if eylem == "olustur":
            ad = request.form["ad"].strip()
            sosyal_kural = request.form.get("sosyal_kural", "").strip() or None
            if not ad:
                flash("Grup adı gerekli.", "hata")
            else:
                grup = Grup(ad=ad, sosyal_kural=sosyal_kural, kurucu_id=current_user.id)
                db.session.add(grup)
                db.session.commit()
                db.session.add(GrupUyeligi(grup_id=grup.id, kullanici_id=current_user.id))
                db.session.commit()
                return redirect(url_for("grup_detay", grup_id=grup.id))
        elif eylem == "katil":
            kod = request.form["davet_kodu"].strip()
            grup = Grup.query.filter_by(davet_kodu=kod).first()
            if not grup:
                flash("Bu davet koduyla eşleşen bir grup bulunamadı.", "hata")
            elif GrupUyeligi.query.filter_by(grup_id=grup.id, kullanici_id=current_user.id).first():
                return redirect(url_for("grup_detay", grup_id=grup.id))
            else:
                db.session.add(GrupUyeligi(grup_id=grup.id, kullanici_id=current_user.id))
                db.session.commit()
                return redirect(url_for("grup_detay", grup_id=grup.id))

    uyelikler = GrupUyeligi.query.filter_by(kullanici_id=current_user.id).all()
    grup_listesi = [db.session.get(Grup, u.grup_id) for u in uyelikler]
    return render_template("gruplar.html", grup_listesi=grup_listesi)


@app.route("/gruplar/<int:grup_id>")
@login_required
def grup_detay(grup_id):
    grup = db.session.get(Grup, grup_id) or abort(404)
    uyelik = GrupUyeligi.query.filter_by(grup_id=grup_id, kullanici_id=current_user.id).first()
    if not uyelik:
        abort(403)

    yaklasan_maclar = Mac.query.filter(Mac.durum == "planlandi").order_by(Mac.baslangic).all()

    kullanici_tahminleri = {
        t.mac_id: t for t in Tahmin.query.filter_by(grup_id=grup_id, kullanici_id=current_user.id).all()
    }

    # Sezonluk sıralama
    puanlanmis = (
        db.session.query(Tahmin, Kullanici)
        .join(Kullanici, Tahmin.kullanici_id == Kullanici.id)
        .filter(Tahmin.grup_id == grup_id, Tahmin.puan.isnot(None))
        .all()
    )
    puan_tablosu = {}
    for t, k in puanlanmis:
        girdi = puan_tablosu.setdefault(k.kullanici_adi, {"toplam": 0, "mac_sayisi": 0})
        girdi["toplam"] += t.puan
        girdi["mac_sayisi"] += 1
    siralama = sorted(puan_tablosu.items(), key=lambda x: x[1]["toplam"], reverse=True)

    return render_template(
        "grup_detay.html",
        grup=grup,
        yaklasan_maclar=yaklasan_maclar,
        kullanici_tahminleri=kullanici_tahminleri,
        siralama=siralama,
    )


@app.route("/gruplar/<int:grup_id>/tahmin/<int:mac_id>", methods=["POST"])
@login_required
def tahmin_kaydet(grup_id, mac_id):
    uyelik = GrupUyeligi.query.filter_by(grup_id=grup_id, kullanici_id=current_user.id).first()
    if not uyelik:
        abort(403)
    mac = db.session.get(Mac, mac_id) or abort(404)

    if mac.basladi_mi():
        flash("Bu maç zaten başladı — tahmin kilitlendi.", "hata")
        return redirect(url_for("grup_detay", grup_id=grup_id))

    try:
        ev = int(request.form["ev"])
        deplasman = int(request.form["deplasman"])
        if ev < 0 or deplasman < 0 or ev > 20 or deplasman > 20:
            raise ValueError
    except (ValueError, KeyError):
        flash("Geçerli bir skor gir.", "hata")
        return redirect(url_for("grup_detay", grup_id=grup_id))

    mevcut = Tahmin.query.filter_by(grup_id=grup_id, mac_id=mac_id, kullanici_id=current_user.id).first()
    if mevcut:
        mevcut.tahmin_ev = ev
        mevcut.tahmin_deplasman = deplasman
    else:
        db.session.add(Tahmin(
            grup_id=grup_id, mac_id=mac_id, kullanici_id=current_user.id,
            tahmin_ev=ev, tahmin_deplasman=deplasman,
        ))
    db.session.commit()
    flash("Tahminin kaydedildi ⚽", "basari")
    return redirect(url_for("grup_detay", grup_id=grup_id))


# ============ BASİT ADMİN: MAÇ EKLE / SONUÇ GİR ============
# Lokal test için — production'da bu ekran yetkilendirme ile korunmalı
# ya da otomatik fikstür senkronizasyonu ile değiştirilmelidir.

@app.route("/admin/maclar", methods=["GET", "POST"])
@login_required
def admin_maclar():
    if request.method == "POST":
        eylem = request.form.get("eylem")
        if eylem == "ekle":
            mac = Mac(
                ev_sahibi=request.form["ev_sahibi"].strip(),
                deplasman=request.form["deplasman"].strip(),
                lig=request.form.get("lig", "Süper Lig").strip(),
                baslangic=datetime.strptime(request.form["baslangic"], "%Y-%m-%dT%H:%M"),
            )
            db.session.add(mac)
            db.session.commit()
            flash("Maç eklendi.", "basari")
        elif eylem == "sonuc_gir":
            mac = db.session.get(Mac, int(request.form["mac_id"])) or abort(404)
            mac.ev_skor = int(request.form["ev_skor"])
            mac.deplasman_skor = int(request.form["deplasman_skor"])
            mac.durum = "bitti"
            db.session.commit()
            mac_puanlarini_hesapla(mac)
            flash("Sonuç girildi ve puanlar hesaplandı.", "basari")
    tum_maclar = Mac.query.order_by(Mac.baslangic.desc()).all()
    return render_template("admin_maclar.html", tum_maclar=tum_maclar)


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=False, host="0.0.0.0", port=5000)
